## 0.0.7
- added row count to REPORT_TABLE_SIZES()

## 0.0.6
- adding QUERY_REPORT procedure: an improved version of "show processlist;"

## 0.0.5
- renaming engine report proc, adding table size report
- adding revision table to the schema

## 0.0.4
- updating procs to add some more!

## 0.0.3
- added engine_repor() proc to dbatools schema
- added scripts/task.extract-single-table-from-backup.sh

## 0.0.2
- adding schema backup script and memory equations txt file

## 0.0.1
- added PROC_LIST_ALL, PROC_LIST_SCHEMA, PROC_SEARCH, TRIGGER_LIST_ALL, TRIGGER_LIST_SCHEMA, TRIGGER_SEARCH to dbatools schema

